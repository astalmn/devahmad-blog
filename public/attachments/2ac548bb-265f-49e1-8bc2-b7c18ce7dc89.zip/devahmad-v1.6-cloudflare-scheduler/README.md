# DevAhmad v1.6 — Cloudflare Scheduler

يشغّل GitHub workflow الخاص بنشر المقالات المجدولة كل 5 دقائق.

## الملفات
- `src/index.js`: Cloudflare Worker.
- `wrangler.toml`: إعداد Worker وCron كل 5 دقائق.
- لا تعدّل `scripts/publish_scheduled.py`؛ يبقى داخل مستودع DevAhmad الحالي.

## إعداد GitHub Token
أنشئ Fine-grained Personal Access Token من GitHub للحساب الذي يملك المستودع:
- Repository access: Only select repositories → `devahmad-blog`
- Repository permission: Actions → Read and write
- لا تضع التوكن داخل أي ملف ولا GitHub.

## النشر عبر Cloudflare Workers
1. أنشئ Worker جديدًا باسم `devahmad-v1-6-scheduler`.
2. ضع محتوى `src/index.js` ككود الـWorker ثم Deploy.
3. في Settings → Variables and Secrets أضف Secret:
   `GITHUB_TOKEN`
   والقيمة هي GitHub token.
4. أضف Cron Trigger:
   `*/5 * * * *`
5. لا حاجة لإضافة التوقيت إلى Cron. الـWorker فقط يشغّل GitHub Action كل 5 دقائق،
   بينما `publish_scheduled.py` هو المسؤول عن مقارنة وقت المقال باستخدام Asia/Gaza.

## اختبار
- اترك مقالًا مستحقًا للنشر.
- انتظر دورة Cron.
- في GitHub → Actions → Publish scheduled articles يجب أن يظهر تشغيل جديد.
- التشغيل سيظهر كمشغّل عبر workflow_dispatch لأن Worker هو الذي استدعاه.
- افتح `Publish due articles` وتأكد من ظهور اسم المقال.
- بعد commit، انتظر Cloudflare Pages حتى يعيد بناء الموقع.

## أمان
`GITHUB_TOKEN` يجب أن يكون Secret داخل Cloudflare فقط. لا تضعه في `wrangler.toml`
أو `src/index.js` أو المستودع.
