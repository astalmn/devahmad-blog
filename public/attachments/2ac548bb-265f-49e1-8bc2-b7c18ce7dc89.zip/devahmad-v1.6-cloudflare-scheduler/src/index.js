export default {
  async fetch(request, env) {
    // Optional manual health check. Does not expose secrets.
    const url = new URL(request.url);
    if (url.pathname === "/health") {
      return new Response("DevAhmad scheduler is running", { status: 200 });
    }
    return new Response("Not found", { status: 404 });
  },

  async scheduled(controller, env, ctx) {
    ctx.waitUntil(triggerGitHubWorkflow(env));
  },
};

async function triggerGitHubWorkflow(env) {
  const owner = env.GITHUB_OWNER || "astalmn";
  const repo = env.GITHUB_REPO || "devahmad-blog";
  const workflow = env.GITHUB_WORKFLOW || "publish-scheduled.yml";
  const branch = env.GITHUB_BRANCH || "main";

  if (!env.GITHUB_TOKEN) {
    throw new Error("Missing GITHUB_TOKEN secret");
  }

  const endpoint =
    `https://api.github.com/repos/${owner}/${repo}/actions/workflows/${workflow}/dispatches`;

  const response = await fetch(endpoint, {
    method: "POST",
    headers: {
      "Accept": "application/vnd.github+json",
      "Authorization": `Bearer ${env.GITHUB_TOKEN}`,
      "X-GitHub-Api-Version": "2022-11-28",
      "User-Agent": "devahmad-cloudflare-scheduler",
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ ref: branch }),
  });

  if (response.status !== 204) {
    const body = await response.text();
    throw new Error(`GitHub dispatch failed (${response.status}): ${body}`);
  }

  console.log(`Triggered ${workflow} on ${owner}/${repo}@${branch}`);
}
