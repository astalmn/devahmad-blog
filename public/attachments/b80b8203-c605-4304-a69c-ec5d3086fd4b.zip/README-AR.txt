إصلاح زر رفع PDF وZIP في DevAhmad v1.4

المشكلة: الملف المرفوع index (3).html مقطوع في منتصف JavaScript عند الكلمة butt، فلا يتم ربط أزرار المرفقات بالأحداث.

التركيب:
1. استبدل public/editor/index.html فقط بالملف الموجود في هذه الحزمة.
2. اترك functions/api/editor-attachment.js وeditor-upload.js دون تغيير إن كانا موجودين.
3. Commit changes وانتظر نشر Cloudflare.
4. افتح /editor/?v=141 وجرّب الضغط على رفع المرفق دون اختيار ملف. يجب أن تظهر رسالة اختر ملف PDF أو ZIP أولًا.
5. بعد ذلك جرّب PDF صغيرًا واحفظ المقال.
